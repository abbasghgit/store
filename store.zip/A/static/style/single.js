function setImg(input ,index){
   let img = document.querySelector('#y'+input);
   let btn = document.querySelector('#d'+index);
   let pictures = [...document.querySelector('.s-body').children]
   
   
   pictures.forEach((element)=>{
      element.classList.remove('active');
   })
   let btns = [...document.querySelector('.s-bottom').children]
   
   btns.forEach((element)=>{
      element.classList.remove('s-active');
   })
   
   img.classList.add('active');
   btn.classList.add('s-active');
}




function setInfo(input ,index){
   let body = document.querySelector('#'+input);
   let header = document.querySelector('#'+index);
   let information = [...document.querySelector('.i-body').children]
   
   
   information.forEach((element)=>{
      element.classList.remove('active');
   })
   let head = [...document.querySelector('.header').children]
   
   head.forEach((element)=>{
      element.classList.remove('active');
   })
   
   body.classList.add('active');
   header.classList.add('active');
}