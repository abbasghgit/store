from django.contrib.auth.base_user import BaseUserManager

class CustomUserManager(BaseUserManager):
   def create_user(self ,username ,email ,password ,**extra_fields):
      extra_fields.setdefault('role' ,'customer')
      extra_fields.setdefault('phone' ,None)
      extra_fields.setdefault('profile_img' ,None)
      if not username:
         raise ValueError('The username must be set')
         
      email = self.normalize_email(email)
      user = self.model(username= username ,email = email,**extra_fields)
      user.set_password(password)
      user.save()
      return user
   def create_seller(self ,username ,email ,password ,**extra_fields):
      extra_fields.setdefault('role' ,'seller')
      extra_fields.setdefault('is_seller' ,True)
      
      if extra_fields.get('is_seller') is not True:
         raise ValueError(_('seller must be have is_seller = Ture'))
         
      return self.create_user(username ,email, password ,**extra_fields)

   def create_superuser(self ,username ,email,password ,**extra_fields):
      extra_fields.setdefault('role' ,'superuser')
      extra_fields.setdefault('profile_img' ,None)
      extra_fields.setdefault('profile_img' ,None)
      extra_fields.setdefault('is_active' ,True)
      extra_fields.setdefault('is_staff' ,True)
      extra_fields.setdefault('is_superuser' ,True)
      
      if extra_fields.get('is_staff') is not True:
         raise ValueError(_('superuser must be have is_superuser = Ture'))
         
      if extra_fields.get('is_superuser') is not True:
         raise ValueError(_('superuser must be have is_staff = Ture'))
         
      return self.create_user(username ,email, password ,**extra_fields)