from django.db import models
from django.urls import reverse
from accounts.models import CustomUser
from category.models import *
import datetime
# Create your models here.

class Product(models.Model):
   name = models.CharField(max_length =155)
   name_fa = models.CharField(max_length =155,blank =True,null=True)
   slug = models.SlugField(max_length =155 ,blank =True,null=True)
   model = models.CharField(max_length=155)
   seller = models.ForeignKey(
      CustomUser,
      on_delete = models.CASCADE,
      related_name = 'sellers',
   )
   category = models.ForeignKey(
      Category,on_delete =models.SET_NULL ,
      related_name ='category_products' ,
      blank = True,
      null=True,
   )
   brand = models.ForeignKey(
      Brand,
      on_delete =models.SET_NULL ,
      related_name ='brand_products',
      blank = True,
      null=True,
   )
   count = models.PositiveIntegerField(blank=False)
   purchase_price = models.PositiveIntegerField(blank=False)
   price = models.PositiveIntegerField(blank=False)
   sale_price = models.PositiveIntegerField(blank=False)
   is_sale = models.BooleanField(default =False)
   available = models.BooleanField(default =True)
   main_description = models.TextField(max_length=650)
   picture = models.ImageField(upload_to='product/%Y/%m/%d')
   img_1 = models.ImageField(
      upload_to='product/%Y/%m/%d' ,blank=True ,null = True)
   img_2 = models.ImageField(
      upload_to='product/%Y/%m/%d' ,blank=True ,null = True)
   img_3 = models.ImageField(
      upload_to='product/%Y/%m/%d' ,blank=True ,null = True)
   img_4 = models.ImageField(
      upload_to='product/%Y/%m/%d' ,blank=True ,null = True)
   title1 = models.CharField(max_length =155)
   description1 = models.CharField(max_length =155)
   title2 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   description2 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   title3 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   description3 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   title4 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   description4 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   title5 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   description5 = models.CharField(
      max_length =155 ,blank =True ,null = True)
   create = models.DateTimeField(auto_now_add =True)
   
   def get_absolute_url(self):
      return reverse('products:single' ,args=(self.id,))
   
   def user_like(self):
      count = self.pvotes.count()
      return count
   
   def can_user_like(self ,user):
      user_like = user.uvotes.filter(product = self)
      if user_like.exists():
         return True
      return False
      
      
   def __str__(self):
      return f'{self.name} - {self.seller} - {self.available} - {self.is_sale}'
   
class Vote(models.Model):
   product = models.ForeignKey(
      Product,
      on_delete = models.CASCADE,
      related_name = 'pvotes',
   )
   user = models.ForeignKey(
      CustomUser,
      on_delete = models.CASCADE,
      related_name = 'uvotes'
   )
   
   def __str__(self):
      return f'{self.user} liked {self.product}'
   
ANONYMOUS_USER_ID = 2   
   
class Comment(models.Model):
   product = models.ForeignKey(
      Product,
      on_delete = models.CASCADE,
      related_name = 'pcomments',
      blank = False,
   )
   user = models.ForeignKey(
      CustomUser,
      default = ANONYMOUS_USER_ID,
      on_delete = models.SET_DEFAULT,
      related_name = 'ucomments',
      blank = False,
   )
   reply = models.ForeignKey(
      'self',
      on_delete = models.CASCADE,
      related_name = 'replies',
      blank = True,
      null = True,
   )
   is_reply = models.BooleanField(default = False)
   body = models.TextField(max_length = 700)
   available = models.BooleanField(default = False)
   created = models.DateTimeField(default = datetime.datetime.today())
   
   def __str__(self):
      return f'{self.product} - {self.user} - {self.is_reply}'