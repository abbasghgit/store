from django import forms
from .models import *

class ProductCommentForm(forms.ModelForm):
    body = forms.CharField(max_length=700)
    class Meta:
        model = Comment
        fields = ('body',)