from django.shortcuts import render , redirect
from django.views import View
from category.models import *
from products.models import *
# Create your views here.

# we create base views
class Home(View):
   template_name = 'home/home.html'
   def get(self ,request ,*args ,**kwargs):
      categories = Category.objects.all()
      products = Product.objects.all()


      
      if request.GET.get('search'):
         categories = Category.objects.filter(name__contains = request.GET['search'])
      
      context = {'categories' :categories,'products':products}
      return render(request ,self.template_name ,context)