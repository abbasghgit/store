from django.db import models

from accounts.models import *
from products.models import Product
import datetime
# Create your models here.

class Order(models.Model):
   user = models.ForeignKey(
      CustomUser,
      on_delete = models.CASCADE,
      related_name = 'user_orders'
   )
   paid = models.BooleanField(default = False)
   discount = models.IntegerField(blank=True,null=True)
   date = models.DateTimeField(default = datetime.datetime.today())
   
   class Meta:
      ordering = ('paid' , 'date')
      
   def __str__(self):
      return f'{self.user} - {self.paid}'
   
   
class OrderItem(models.Model):
   order = models.ForeignKey(
      Order,
      on_delete = models.CASCADE,
      related_name = 'order_items',
   )
   product = models.ForeignKey(
      Product,
      on_delete = models.CASCADE,
      related_name= 'order_products',
   )
   price = models.PositiveIntegerField()
   quantity = models.PositiveIntegerField()
   
   def get_cost(self):
      return int(self.price * self.quantity)
    
   def __str__(self):
      return f'{self.order.user} - {self.product}'
   