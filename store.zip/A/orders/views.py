from django.shortcuts import render , get_object_or_404 ,redirect
from django.http import HttpResponse ,JsonResponse
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from products.models import Product
from .cart import Cart
from .models import *
from .forms import *
# Create your views here.
class CartView(View):
    template_name = 'orders/cart.html'
    def get(self ,request):
#        context = {
 #           'products': products,
  #          'get_total_price':get_total_price,
  #          'quantity':
#}
        return render(request ,self.template_name)
    

def AddCartView(request):
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        product_id = request.POST.get('product_id')
        quantity = request.POST.get('quantity')
        cart.add_cart(product_id=product_id,quantity=quantity)
        qty = cart.__len__()
        return JsonResponse({'qty':qty})
    
class RemoveCartView(View):
    def get(self,request,product_id):
        cart = Cart(request)
        cart.remove_cart(product_id)
        messages.success(request, 'محصول با موفقییت حذف شد','info')
        return redirect('orders:cart')
    
# اتمام سبد خرید

class OrderCreateView(LoginRequiredMixin ,View):
    def get(self ,request):
        order = Order.objects.create(user =request.user)
        order.save()
        cart = Cart(request)
        for item in cart:
            order_item = OrderItem.objects.create(
                order = order,
                product = item['product'],
                price = item['price'],
                quantity = item['quantity'],
            )
            order_item.save()
        cart.clear_cart()
        return redirect('orders:orders')# .HINT
    
class OrderView(LoginRequiredMixin ,View):
    form_class = OrderForm
    template_name = 'orders/orders.html'
    def get(self ,request):
        context = {'form':self.form_class}
        return render(request ,self.template_name ,context)